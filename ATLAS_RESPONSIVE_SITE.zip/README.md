# ATLAS – Class 10 Social Science 2026–27
Open `index.html` locally, or deploy to GitHub Pages: upload everything in this folder to a repo → Settings → Pages → Deploy from branch (main / root).
Folders: `source/` (extracted textbook & question-bank text, linked from Teacher view), `reference/` (previous ATLAS site).
Presentation-mode images and definitions load live from Wikipedia (needs internet); if an image fails, a link to the article appears.
Not included: the commercial Full Marks guide text (copyrighted, reference only) and the page-image PDFs (not supplied).
Note: the source/ folder holds NCERT text — keep the repo private or delete source/ if you publish publicly.
