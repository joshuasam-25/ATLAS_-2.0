const {subjects,chapters}=window.ATLAS,LIB=window.LIB,$=s=>document.querySelector(s),app=$('#app'),pres=$('#pres');
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const S=id=>subjects.find(s=>s.id===id),C=id=>chapters.find(c=>c.id===id),col=id=>`style="--c:var(--${id})"`;
const wl=t=>'https://en.wikipedia.org/wiki/Special:Search?search='+encodeURIComponent(t);
let P={};try{P=JSON.parse(localStorage.getItem('atlas-progress')||'{}')}catch(e){}
const save=()=>{try{localStorage.setItem('atlas-progress',JSON.stringify(P))}catch(e){}};
const done=c=>c.coverage_sections_to_teach.filter((_,i)=>P[c.chapter_id+':'+i]).length,pct=c=>Math.round(100*done(c)/c.coverage_sections_to_teach.length);
const allQ=chapters.flatMap(c=>c.qbank.map(q=>({...q,cid:c.chapter_id,ct:c.title,sub:c.sub})));
const tbl=(head,rows)=>`<div class="tw"><table><tr>${head.map(h=>`<th>${esc(h)}</th>`).join('')}</tr>${rows.map(r=>`<tr>${r.map(v=>`<td>${/^https?:\/\//.test(v)?`<a href="${esc(v)}" target="_blank" rel="noopener">${esc(v)}</a>`:esc(v)}</td>`).join('')}</tr>`).join('')}</table></div>`;
const otbl=rows=>rows.length?tbl(Object.keys(rows[0]),rows.map(r=>Object.values(r))):'';
// Wikipedia
const cache={};
async function wiki(t){
  if(cache[t])return cache[t];
  const sum=async x=>{const r=await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(x.replace(/ /g,'_')));if(!r.ok)throw 0;return r.json()};
  let j;try{j=await sum(t)}catch(e){try{const o=await(await fetch('https://en.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&origin=*&search='+encodeURIComponent(t))).json();j=await sum(o[1][0])}catch(e2){j=null}}
  return cache[t]=j?{title:j.title,extract:j.extract,img:(j.originalimage&&j.thumbnail?j.thumbnail.source.replace(/\/\d+px-/,'/800px-'):j.thumbnail?.source)||'',url:j.content_urls.desktop.page}:{title:t,extract:'',img:'',url:wl(t)};
}
// sidebar
$('#side').innerHTML=`<a class="logo" href="#/">🌍 ATLAS<small>CLASS 10 · SOCIAL SCIENCE · 2026–27</small></a><a href="#/">Home</a><a href="#/practice">Practice &amp; question bank</a><a href="#/maps">Map work</a><a href="#/lib">Data library</a><a href="#/resources">Official links</a>`+subjects.map(s=>`<h4 ${col(s.id)}>${s.name}</h4>`+chapters.filter(c=>c.sub===s.id).map(c=>`<a class="ch" href="#/c/${c.chapter_id}">${c.chapter_number}. ${esc(c.title)}</a>`).join('')).join('');
$('#menu').onclick=()=>$('#side').classList.toggle('open');
function home(){
  const nsec=chapters.reduce((a,c)=>a+c.coverage_sections_to_teach.length,0),d=chapters.reduce((a,c)=>a+done(c),0);
  app.innerHTML=`<div class="hero"><h1>ATLAS</h1><p>Class 10 CBSE Social Science · Session 2026–27 · built on the four NCERT books carrying the 2026–27 reprint label.</p><div class="stats"><div><b>22</b><span>chapters</span></div><div><b>${nsec}</b><span>teaching sections</span></div><div><b>${allQ.length}</b><span>question-bank prompts</span></div><div><b>${chapters.reduce((a,c)=>a+c.maps.length,0)}</b><span>map-work items</span></div><div><b>${d}/${nsec}</b><span>sections done</span></div></div></div>
  <div class="grid">${subjects.map(s=>{const cs=chapters.filter(c=>c.sub===s.id),p=Math.round(100*cs.reduce((a,c)=>a+done(c),0)/cs.reduce((a,c)=>a+c.coverage_sections_to_teach.length,0));
  return`<a class="card" ${col(s.id)} href="#/s/${s.id}"><h3>${s.name}</h3><small>${esc(s.book)}</small><p>${cs.length} chapters</p><div class="bar" ${col(s.id)}><i style="width:${p}%"></i></div><small>${p}% covered</small></a>`}).join('')}</div>`;
}
function subject(id){
  const s=S(id);if(!s)return home();
  app.innerHTML=`<p class="mute"><a href="#/">Home</a> › ${s.name}</p><h1 ${col(id)} style="color:var(--c)">${s.name}</h1><p class="mute">${esc(s.book)} · Class ${s.class} · ${esc(s.session)}</p>
  <div class="tvonly"><b>Teacher view</b> · Book prelims: ${esc(s.prelims_source)} · <a href="source/textbooks/${s.prelims_text_file}" target="_blank">prelims text</a>${s.appendix_source?` · Appendix: ${esc(s.appendix_source)} · <a href="source/textbooks/${s.appendix_text_file}" target="_blank">appendix text</a>`:''}</div>
  <div class="grid">${chapters.filter(c=>c.sub===id).map(c=>`<a class="card" ${col(id)} href="#/c/${c.chapter_id}"><span class="tag">Chapter ${c.chapter_number}</span><h3>${esc(c.title)}</h3><small>${esc(c.original_learning_summary.slice(0,120))}…</small><div class="bar"><i style="width:${pct(c)}%"></i></div><small>${done(c)}/${c.coverage_sections_to_teach.length} sections</small></a>`).join('')}</div>`;
}
function chapter(id){
  const c=C(id);if(!c)return home();const s=S(c.sub),cw=c.crosswalk||{};
  app.innerHTML=`<div ${col(c.sub)}><p class="mute"><a href="#/">Home</a> › <a href="#/s/${s.id}">${s.name}</a> › Chapter ${c.chapter_number}</p>
  <h1 style="color:var(--c)">${esc(c.title)}</h1><p><span class="tag">${esc(s.book)}</span> <span class="tag ok">Verified</span> <span class="tag" style="--c:#667085">${esc(cw.exam_scope||'')}${cw.scope_status?' · '+esc(cw.scope_status):''}</span></p>
  <p style="font-size:1.08rem">${esc(c.original_learning_summary)}</p>
  <p><button class="btn" id="pb">▶ Present with images</button><a class="btn ghost" href="#/flash/${c.chapter_id}">🃏 Flashcards</a><button class="btn ghost" onclick="print()">Print</button></p>
  <div class="sec"><h2>Sections to teach <small>${pct(c)}% done</small></h2><div class="bar"><i style="width:${pct(c)}%"></i></div>${c.coverage_sections_to_teach.map((x,i)=>`<label class="ck"><input type="checkbox" data-k="${c.chapter_id}:${i}" ${P[c.chapter_id+':'+i]?'checked':''}> ${esc(x)} <a href="${wl(c.wiki[i])}" target="_blank" rel="noopener">Wikipedia ↗</a></label>`).join('')}</div>
  <div class="sec"><h2>Key terms</h2><div class="chips">${c.key_terms_to_define.map(t=>`<a href="${wl(t)}" target="_blank" rel="noopener">${esc(t)}</a>`).join('')}</div></div>
  ${cw.learning_targets?`<div class="sec"><h2>Learning targets &amp; coverage</h2><p>${esc(cw.learning_targets)}</p><p><b>Lesson coverage:</b> ${esc(cw.lesson_coverage_seed)}</p><details><summary>Full syllabus record</summary>${otbl([cw])}</details></div>`:''}
  ${c.seeds.length?`<div class="sec"><h2>Lesson topic plan (${c.seeds.length})</h2>${otbl(c.seeds)}</div>`:''}
  ${c.maps.length?`<div class="sec"><h2>Map work (${c.maps.length})</h2>${otbl(c.maps)}</div>`:''}
  <div class="sec"><h2>Question bank (${c.qbank.length})</h2>${c.qbank.length?`<details><summary>Show all ${c.qbank.length} prompts</summary>${otbl(c.qbank)}</details>`:'<p class="mute">No prompts indexed for this chapter.</p>'}</div>
  <div class="sec"><h2>Textbook source</h2><p>Source PDF <b>${esc(c.source_filename)}</b> · ${c.pdf_page_count} pages · reprint ${esc(c.source_reprint_label)}</p>
  <div class="tvonly"><b>Teacher view</b> · Extracted pages: ${c.extracted_page_count} · Characters: ${c.extracted_characters} · SHA-256: ${c.source_sha256} · <a href="source/textbooks/${c.text_file}" target="_blank">Extracted source text</a></div>
  <details><summary>Headings detected (${c.headings_detected.length})</summary><ol>${c.headings_detected.map(h=>`<li>${esc(h)}</li>`).join('')}</ol></details>
  <details><summary>Question-line candidates from the textbook (${c.question_line_candidates.length})</summary><ol>${c.question_line_candidates.map(h=>`<li>${esc(h)}</li>`).join('')}</ol></details>
  <p class="mute"><small>${esc(c.public_site_content_rule||'')}</small></p></div></div>`;
  app.querySelectorAll('input[data-k]').forEach(i=>i.onchange=()=>{P[i.dataset.k]=i.checked;save();const y=scrollY;chapter(id);scrollTo(0,y)});
  $('#pb').onclick=()=>present(c);
}
// presentation with Wikipedia images
function present(c){
  const sl=[{k:'t',h:c.title,p:c.original_learning_summary,w:c.wiki[0]},...c.coverage_sections_to_teach.map((x,i)=>({k:'s',h:x,w:c.wiki[i],n:`Section ${i+1} of ${c.coverage_sections_to_teach.length}`})),...c.key_terms_to_define.map(t=>({k:'k',h:t,w:t,n:'Key term'})),{k:'r',h:'Recap',l:c.coverage_sections_to_teach}];
  let i=0;pres.hidden=false;pres.style.setProperty('--c',`var(--${c.sub})`);
  const draw=async()=>{const x=sl[i],tok=i;
    pres.innerHTML=`<div class="pb"><span class="mute">${i+1}/${sl.length}</span><button class="btn ghost" id="a">←</button><button class="btn" id="b">→</button><button class="btn ghost" id="x">✕</button></div><div class="sl ${x.k==='r'?'one':''}"><div><div class="mute" style="font-size:.5em">${esc(c.title)} ${x.n?'· '+esc(x.n):''}</div><h2>${esc(x.h)}</h2>${x.k==='r'?`<ul>${x.l.map(l=>`<li>${esc(l)}</li>`).join('')}</ul>`:x.k==='t'?`<p>${esc(x.p)}</p>`:'<p id="df" class="mute">Loading definition…</p>'}</div>${x.k==='r'?'':'<div class="im" id="im"><div class="ph">Loading image…</div></div>'}</div><div class="dots">←/→ keys · Esc to exit</div>`;
    $('#a').onclick=()=>go(-1);$('#b').onclick=()=>go(1);$('#x').onclick=close;if(x.k==='r')return;
    const w=await wiki(x.w);if(tok!==i)return;
    const link=`<a href="${esc(w.url)}" target="_blank" rel="noopener">${esc(w.title)} — Wikipedia ↗</a>`;
    if($('#df'))$('#df').innerHTML=w.extract?`${esc(w.extract.length>380?w.extract.slice(0,380).replace(/\s\S*$/,'')+'…':w.extract)}`:'';
    $('#im').innerHTML=w.img?`<img src="${esc(w.img)}" alt="${esc(w.title)}">${'<br>'+link}`:`<div class="ph">No image available — open the article for pictures &amp; definition:<br>${link}</div>`;
    const im=$('#im img');if(im)im.onerror=()=>{$('#im').innerHTML=`<div class="ph">Image didn't load. Open it here:<br>${link}</div>`};
    if(sl[i+1]&&sl[i+1].w)wiki(sl[i+1].w)};
  const go=d=>{i=Math.max(0,Math.min(sl.length-1,i+d));draw()},close=()=>{pres.hidden=true;removeEventListener('keydown',k)};
  const k=e=>{if(e.key==='ArrowRight')go(1);if(e.key==='ArrowLeft')go(-1);if(e.key==='Escape')close()};addEventListener('keydown',k);draw();
}
function flash(id){
  const c=C(id);if(!c)return home();
  app.innerHTML=`<p class="mute"><a href="#/c/${id}">← ${esc(c.title)}</a></p><h1>Flashcards · ${esc(c.title)}</h1><p class="mute">Tap a card to reveal the Wikipedia definition.</p><div class="grid" ${col(c.sub)}>${c.key_terms_to_define.map((t,i)=>`<div class="fc" data-t="${esc(t)}" tabindex="0"><div class="f">${esc(t)}</div></div>`).join('')}</div>`;
  app.querySelectorAll('.fc').forEach(el=>el.onclick=async()=>{const t=el.dataset.t,b=el.firstChild;if(b.className!=='f'){b.className='f';b.textContent=t;return}b.className='';b.textContent='Loading…';const w=await wiki(t);b.innerHTML=w.extract?esc(w.extract.slice(0,260))+'… <a href="'+esc(w.url)+'" target="_blank">more</a>':`No summary found. <a href="${wl(t)}" target="_blank">Search Wikipedia</a>`});
}
let timer;
function practice(){
  clearInterval(timer);
  app.innerHTML=`<h1>Practice &amp; question bank</h1><p class="mute">${allQ.length} prompts from your question bank, with their source line numbers.</p>
  <p><select id="pc"><option value="">All chapters</option>${chapters.map(c=>`<option value="${c.chapter_id}">${c.chapter_id} ${esc(c.title)} (${c.qbank.length})</option>`).join('')}</select> <input id="pf" placeholder="Filter text…" style="padding:.45rem .8rem;border:1px solid var(--line);border-radius:99px"> <select id="pn"><option>5</option><option selected>10</option><option>15</option></select> <button class="btn" id="go">⏱ Timed set</button> <b id="tm"></b></p><div id="pl"></div>`;
  const filt=()=>allQ.filter(q=>(!$('#pc').value||q.cid===$('#pc').value)&&(!$('#pf').value||q.prompt_excerpt.toLowerCase().includes($('#pf').value.toLowerCase())));
  const list=()=>{const r=filt();$('#pl').innerHTML=`<p class="mute">${r.length} matches${r.length>300?' (showing first 300)':''}</p>`+tbl(['Chapter','Prompt','Section heading','Marks','Year / session','Source line','Syllabus status'],r.slice(0,300).map(q=>[q.cid,q.prompt_excerpt,q.section_heading,q.marks,q.year_or_session_label,q.source_line,q.syllabus_status]))};
  $('#pc').onchange=$('#pf').oninput=list;list();
  $('#go').onclick=()=>{const pool=filt().sort(()=>Math.random()-.5).slice(0,+$('#pn').value);$('#pl').innerHTML=`<ol>${pool.map(q=>`<li>${esc(q.prompt_excerpt)} <small>— ${esc(q.ct)}</small></li>`).join('')}</ol>`;
    let t=pool.length*90;clearInterval(timer);timer=setInterval(()=>{t--;$('#tm').textContent=`${Math.floor(t/60)}:${String(t%60).padStart(2,'0')}`;if(t<=0){clearInterval(timer);$('#tm').textContent='Time up'}},1000)};
}
function maps(){
  const rows=chapters.flatMap(c=>c.maps.map(m=>[S(c.sub).name,...Object.values(m)]));
  app.innerHTML=`<h1>Map work</h1><p class="mute">${rows.length} items · map images are not included; use the textbook atlas pages.</p>${tbl(['Subject','Subject (source)','Chapter','Category','Item','Notes','Source','Verification'],rows)}`;
}
function lib(i){
  if(i!==undefined&&i!==''){const all=[...LIB.tables.map(t=>({...t,tb:1})),...LIB.docs],t=all[+i];
    return app.innerHTML=`<p><a href="#/lib">← Data library</a></p><h1>${esc(t.name)}</h1>`+(t.tb?tbl(t.head,t.rows):`<pre>${esc(t.text)}</pre>`)}
  app.innerHTML=`<h1>Data library</h1><p class="mute">Every file from your ATLAS package, available in full.</p><div class="sec"><h2>Tables</h2><ul>${LIB.tables.map((t,k)=>`<li><a href="#/lib/${k}">${esc(t.name)}</a> <small>${t.rows.length} rows</small></li>`).join('')}</ul></div>
  <div class="sec"><h2>Documents</h2><ul>${LIB.docs.map((t,k)=>`<li><a href="#/lib/${LIB.tables.length+k}">${esc(t.name)}</a></li>`).join('')}</ul></div>
  <div class="sec"><h2>Source files</h2><ul><li><a href="source/question_bank/QUESTION_BANK-X_merged_EXTRACTED.txt" target="_blank">Question bank — full extracted text</a></li><li><a href="source/textbooks/ATLAS_FOUR_BOOKS_COMPLETE_COVERAGE.json" target="_blank">Four-books coverage JSON</a></li><li><a href="reference/ATLAS_Class10_Social_Science_COMPLETE_TEACHING.html" target="_blank">Previous ATLAS teaching site</a></li><li>Chapter text files: Teacher view on each chapter page</li></ul></div>`;
}
function resources(){
  const L=[['CBSE Class X curriculum 2026–27','https://cbseacademic.nic.in/curriculum_2027.html'],['CBSE sample papers & marking schemes 2026–27','https://cbseacademic.nic.in/sqp_classx_2026-27.html'],['CBSE previous-year question papers','https://www.cbse.gov.in/cbsenew/question-paper.html'],['CBSE previous-year marking schemes','https://www.cbse.gov.in/cbsenew/marking-scheme.html'],['NCERT textbook portal','https://ncert.nic.in/textbook.php']];
  app.innerHTML=`<h1>Official links</h1><div class="grid">${L.map(l=>`<a class="card" href="${l[1]}" target="_blank" rel="noopener"><h3>${l[0]}</h3><small>${l[1]}</small></a>`).join('')}</div>`;
}
function search(q){
  q=q.trim().toLowerCase();if(!q)return route();
  const r=chapters.filter(c=>[c.title,c.original_learning_summary,...c.coverage_sections_to_teach,...c.key_terms_to_define,...c.headings_detected].join(' ').toLowerCase().includes(q)),qq=allQ.filter(x=>x.prompt_excerpt.toLowerCase().includes(q));
  app.innerHTML=`<h1>Results for “${esc(q)}”</h1><h3>Chapters (${r.length})</h3><div class="grid">${r.map(c=>`<a class="card" ${col(c.sub)} href="#/c/${c.chapter_id}"><span class="tag">${S(c.sub).name} · Ch ${c.chapter_number}</span><h3>${esc(c.title)}</h3></a>`).join('')}</div><h3>Question-bank prompts (${qq.length})</h3>${tbl(['Chapter','Prompt','Source line'],qq.slice(0,60).map(x=>[x.cid,x.prompt_excerpt,x.source_line]))}`;
}
function route(){const[,t,id]=location.hash.split('/');scrollTo(0,0);clearInterval(timer);$('#side').classList.remove('open');({s:subject,c:chapter,flash,practice,maps,lib,resources}[t]||home)(id)}
addEventListener('hashchange',()=>{$('#q').value='';route()});$('#q').oninput=e=>search(e.target.value);
$('#teach').onchange=e=>document.body.classList.toggle('t',e.target.checked);route();
